import io
import pymongo
import urllib, base64
import matplotlib.pyplot as plt

from datetime import datetime
from django.shortcuts import render

# Creates a function that we called will render index.html in templates folder.
def stats(request):

   # Connects to my MongoDB and fetches data.
   api = 'mongodb+srv://DB033:OIwEvLXOpxwZDMcS@covid19data.tabyt.mongodb.net/host_data?retryWrites=true&w=majority'
   client = pymongo.MongoClient(api)

   db = client.get_database('host_data')
   collection = db.covid_data
   
   # Collect a limit of 500 dictionaries and add it to a list.
   data = list(collection.find({}).limit(500))

   stats_contain = {}

   max_case = []
   min_case = []
   max_death = []
   min_death = []

   #  Returns specific data to dict stats_contain
   #  Loop iterates and add all Cases and Deaths to an list in a dictionary and send it to stats_contain.
   for i in data:
      if i['ISO_CODE'] in stats_contain:
         stats_contain[i['ISO_CODE']]['Cases'].append(i['TotalCase'])
         stats_contain[i['ISO_CODE']]['Fatalities'].append(i['TotalDeath'])
         
      
      elif i['ISO_CODE'] not in stats_contain:
         stats_contain[i['ISO_CODE']] = {'Country': i['COUNTRY_NAME'], 'Fatalities': [i['TotalDeath']], 'Cases': [i['TotalCase']]}

   #  Gets the specified.
   for i in stats_contain:
      max_case.append(max(stats_contain[i]['Cases']))
      min_case.append(min(stats_contain[i]['Cases']))
      max_death.append(max(stats_contain[i]['Fatalities']))
      min_death.append(min(stats_contain[i]['Fatalities']))

   stats = {}

   name = []
   death = []
   cases = []

   for i in data:
      stats[i['ISO_CODE']] = {'Country': i['COUNTRY_NAME'], 'Fatalities': i['TotalDeath'], 'Cases': i['TotalCase']}

   for a in stats:
      name.append(stats[a]['Country'])
      death.append(stats[a]['Fatalities'])
      cases.append(stats[a]['Cases'])

   # Creates line graph
   fig= plt.figure(figsize=(15,10))

   plt.plot(name, max_case, '-g', label='Cases Reported')
   plt.plot(name, max_death, '--r', label='Fatality Rate')

   plt.xlabel('Country')  
   plt.ylabel('Frequency of fatalities & inffections')
   plt.xticks(name, name, rotation='vertical')
   plt.tick_params(axis='x', colors='white')
   plt.tick_params(axis='y', colors='white')

   plt.grid(b=True, which='minor', color='grey', linestyle='dotted', alpha=0.2)
   plt.minorticks_on()
   leg = plt.legend()
   plt.legend(loc='upper left', frameon=False)


   line_buf = io.BytesIO()
   plt.savefig(line_buf, format='png', transparent=True)
   line_buf.seek(0)
   line_code = base64.b64encode(line_buf.read())
   line_graph = urllib.parse.quote(line_code)

   # Creates bar graph
   fig= plt.figure(figsize=(15,10))
   
   plt.bar(name, max_case)
   
   plt.xlabel('Country')  
   plt.ylabel('Number of fatalities')
   plt.xticks(name, name, rotation='vertical')
   plt.tick_params(axis='x', colors='white')
   plt.tick_params(axis='y', colors='white')

   plt.grid(b=True, which='minor', color='#28afee', linestyle='dotted', alpha=0.2)
   plt.minorticks_on()

   bar_buf = io.BytesIO()
   plt.savefig(bar_buf, format='png', transparent=True)
   bar_buf.seek(0)
   bar_code = base64.b64encode(bar_buf.read())
   bar_graph = urllib.parse.quote(bar_code)

   # Creates Pie Chart
   fig = plt.figure()
   ax = fig.add_axes([0,0,1,1])
   ax.axis('equal')
   ax.pie(max_case, labels=name, autopct='%1.2f%%')

   my_circle=plt.Circle( (0,0), 0.7, color='white')
   p=plt.gcf()
   p.gca().add_artist(my_circle)
   p.set_size_inches(13,13)
   
   # Displays data to the Django application
   pie_buf = io.BytesIO()
   plt.savefig(pie_buf, format='png', transparent=True)
   pie_buf.seek(0)
   pie_code = base64.b64encode(pie_buf.read())
   pie_graph = urllib.parse.quote(pie_code)
   return render(request, 'index.html', {'line': line_graph, 'bar':bar_graph, 'pie':pie_graph})