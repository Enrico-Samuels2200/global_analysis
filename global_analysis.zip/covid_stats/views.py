from django.shortcuts import render

# Creates a function that we called will render index.html in templates folder.
def stats(request):
   return render(request, 'index.html', {})