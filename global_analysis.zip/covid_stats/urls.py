from django.urls import path
from . import views

# Sets the main path to "http://localhost:8000/"
urlpatterns = [
    path('', views.stats, name='stats'),
]
