from django.apps import AppConfig


class CovidStatsConfig(AppConfig):
    name = 'covid_stats'
